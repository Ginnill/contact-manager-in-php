<footer class="main pt-4">
    <div class="container">
        <div class="d-flex justify-content-center py-3">
            <p class="text">Made by Gustavo Fortunato <span class="text-danger"> ♡ </span></p>
        </div>
    </div>
</footer>