<header class="main">
    <div class="container">
        <nav class="logo-box d-flex justify-content-center py-5">
            <p class="logo text">Fortunato</p>
            <p class="logo text">Fortunato</p>
        </nav>
    </div>
</header>