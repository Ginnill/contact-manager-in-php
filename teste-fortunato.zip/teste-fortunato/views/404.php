

<section class="404">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="error-template col-12 d-flex flex-column jusfity-content-center text-center">
                    <h1 class="title">
                        Oops! Erro 404</h1>
                    <div class="error-details text">
                        Essa página não existe, volte para o inicio clicando no botão abaixo.
                    </div>
                    <div class="error-actions text mt-5">
                        <a href="/teste-fortunato/" class="btn px-5 btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                            Início
                        </a>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</section>

